﻿using System;
using System.Collections.Generic;
using System.IO;

namespace _08.Full_Directory_Traversal
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
